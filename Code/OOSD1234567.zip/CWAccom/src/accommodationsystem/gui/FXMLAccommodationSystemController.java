package accommodationsystem.gui;

import accommodationsystem.model.Accommodation;
import accommodationsystem.model.AccommodationSystem;
import accommodationsystem.model.AccommodationSystemException;
import accommodationsystem.model.Area;
import accommodationsystem.model.Guest;
import accommodationsystem.model.GuestBooking;
import accommodationsystem.model.CleaningStatus;
import accommodationsystem.model.CleaningStatus.Status;
import static accommodationsystem.model.CleaningStatus.Status.CLEAN;
import static accommodationsystem.model.CleaningStatus.Status.DIRTY;
import static accommodationsystem.model.CleaningStatus.Status.MAINTENANCE;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 */
public class FXMLAccommodationSystemController implements Initializable
{

    @FXML
    private ChoiceBox<Area> cbArea;
    @FXML
    private ChoiceBox<CleaningStatus.Status> cbStatus;
    @FXML
    private CheckBox checkBreakfast;
    @FXML
    private TextField txtNumBreakfasts;
    @FXML
    private TextField txtAreaDescription;
    @FXML
    private TextField txtNumRequireCleaning;
    @FXML
    private TableView<AccommodationRow> tblAccommodations;

    // THE ATTRIBUTES BELOW ARE MANUALLY ADDED
    private ObservableList<Area> areaData = FXCollections.observableArrayList();
    
    private ObservableList<AccommodationRow> tableData = FXCollections.observableArrayList();
    @FXML
    private TextField txtAccommType;
    @FXML
    private TextField txtAccommNumber;
    @FXML
    private TextField txtAccommodates;
    @FXML
    private TextField txtrPricePerNight;
    @FXML
    private TextField txtFirstName;
    @FXML
    private TextField txtLastName;
    @FXML
    private Button btnCheckIn;
    @FXML
    private Button btnCheckOut;
    @FXML
    private TextField txtNumberGuests;
    @FXML
    private TextField txtCheckInDate;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb)
    {
        AccommodationSystem accommodationSystem = AccommodationSystem.getInstance();
        
        ArrayList<Area> zones = accommodationSystem.getAreas();
        
        for (int i = 0; i<zones.size(); i++)
        {
            areaData.add(zones.get(i));
        }
        
        // Associate the choice box data with the choice box
        cbArea.setItems(areaData);
        // Set the default entry to the first in the list
        cbArea.setValue(areaData.get(0));
       
        // Set on action does not exist in scene builder
        cbArea.setOnAction(this::cbAreaOnAction);
            
    
        // Initialize the status choice box with enum values
        cbStatus.setItems(FXCollections.observableArrayList(CleaningStatus.Status.values()));
        cbStatus.setValue(CleaningStatus.Status.CLEAN); // Set default value
        cbStatus.setOnAction(this::cbStatusOnAction);

        tblAccommodations.setEditable(false);
        
        TableColumn accommNoCol = new TableColumn("Accomm No");
        accommNoCol.setMinWidth(50);
        
        TableColumn typeCol = new TableColumn("Accomm Type");
        typeCol.setMinWidth(100);
        
        TableColumn OccupancyCol = new TableColumn("Occupancy");
        typeCol.setMinWidth(100);
        
        TableColumn AvailableCol = new TableColumn("Availability");
        typeCol.setMinWidth(100);
        
        TableColumn StatusCol = new TableColumn("Status");
        typeCol.setMinWidth(100);
        
        TableColumn GuestsCol = new TableColumn("Guests");
        typeCol.setMinWidth(100);
        
        TableColumn BreakfastCol = new TableColumn("Breakfast");
        typeCol.setMinWidth(100);
        
        tblAccommodations.getColumns().addAll(accommNoCol,
                                              typeCol,
                                              OccupancyCol,
                                              AvailableCol,
                                              StatusCol,
                                              GuestsCol,
                                              BreakfastCol);
        
        accommNoCol.setCellValueFactory(new PropertyValueFactory<AccommodationRow, String>("accommodationNumber"));
        typeCol.setCellValueFactory(new PropertyValueFactory<AccommodationRow, String>("accommodationType"));
        OccupancyCol.setCellValueFactory(new PropertyValueFactory<AccommodationRow, String>("accommodationOccupancy"));
        AvailableCol.setCellValueFactory(new PropertyValueFactory<AccommodationRow, String>("accommodationAvailable"));
        StatusCol.setCellValueFactory(new PropertyValueFactory<AccommodationRow, String>("accommodationStatus"));
        GuestsCol.setCellValueFactory(new PropertyValueFactory<AccommodationRow, String>("accommodationGuests"));
        BreakfastCol.setCellValueFactory(new PropertyValueFactory<>("accommodationBreakfast"));
        
       
        // tblRoomDetails.setSelectionModel(SelectionMode.SINGLE);
        tblAccommodations.setItems(tableData);
        
        tblAccommodations.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
        if (newSelection != null) {
            System.out.println(newSelection.getAccommodationNumber());
            accommodationSelected(newSelection);
        }
        });

    }
    
    private void accommodationSelected(AccommodationRow newSelection)
    {
        // Retrieve the accommodation object from the row
        Accommodation accommodation = newSelection.getAccommodation();
        
        txtAccommType.setText(accommodation.getAccommodationType());
        txtAccommNumber.setText(Integer.toString(accommodation.getAccommodationNumber()));
        txtAccommodates.setText(Integer.toString(accommodation.getAccommodates()));
        txtrPricePerNight.setText("£" + Integer.toString(accommodation.getPrice()));

        if (accommodation.hasGuestBooking()) {        
            displayCheckinDetails(accommodation.getGuestBooking());
        } else {
            clearCheckinDetails();
        }
 
        if (accommodation.hasGuestBooking())
        {        
            displayCheckinDetails(accommodation.getGuestBooking());
        }
        else
        {
            clearCheckinDetails();
        }
    }

    private void cbAreaOnAction(ActionEvent event) 
    {
        // Retrieve the area instance selected
        Area area = cbArea.getValue();
        
        System.out.println("Area selected: " + area);   // DEBUG
        
        // Set the area description - retrieve from the area instance
        txtAreaDescription.setText(area.getDescription());
        
        // Display the area statistics for the selected area
        showAreaStatistics(area);
        
        // POPULATE THE TABLE WITH ACCOMMODATION FOR THE AREA
        populateTable(area);
    }
    
    private void cbStatusOnAction(ActionEvent event) {
        // Get the selected status from the choice box
        CleaningStatus.Status selectedStatus = cbStatus.getValue();

        System.out.println("Status selected: " + selectedStatus);   // DEBUG

        // Get the currently selected accommodation row from the table
        int selectedIndex = tblAccommodations.getSelectionModel().getSelectedIndex();
        if (selectedIndex >= 0) {
            AccommodationRow selectedRow = tblAccommodations.getSelectionModel().getSelectedItem();
            if (selectedRow != null) {
                // Get the actual accommodation object
                Accommodation accommodation = selectedRow.getAccommodation();

                // Set the new cleaning status
                accommodation.setAccommodationStatus(selectedStatus);

                // Update the table to reflect the changes
                refreshSelectedAccommodation();
            }
        } else {
            // No accommodation selected
            System.out.println("Please select an accommodation first");
        }
    }

    // Helper method to refresh the selected row in the table
    private void refreshSelectedAccommodation() {
        int selectedIndex = tblAccommodations.getSelectionModel().getSelectedIndex();
        if (selectedIndex >= 0) {
            // Refresh the table data to show the updated status
            populateTable((Area) cbArea.getValue());

            // Re-select the previously selected row
            tblAccommodations.getSelectionModel().select(selectedIndex);
        }
    }
    
    private void populateTable(Area area) {
        System.out.println("Populate Table Called");

        // Clear the existing data
        tableData.clear();

        // Get the accommodations for the area
        ArrayList<Accommodation> accommodations = area.getAccommodations();

        // Add the accommodations to the table
        for (Accommodation accommodation : accommodations) {
            // Create the accommodation row
            AccommodationRow accommodationRow = new AccommodationRow(
                    accommodation.getAccommodationNumber(),
                    accommodation.getAccommodationType(),
                    accommodation.getAccommodationOccupancy(),
                    accommodation.getAccommodationAvailable(),
                    accommodation.getCleaningStatus(),
                    accommodation);

            // Set guest and breakfast information
            if (accommodation.hasGuestBooking()) {
                GuestBooking booking = accommodation.getGuestBooking();
                // Set guest count
                String guestCount = String.valueOf(booking.getNumberOfGuests());
                accommodationRow.setAccommodationGuests(guestCount);

                // Set breakfast information using the boolean parameter
                accommodationRow.setAccommodationBreakfast(booking.isBreakfastRequired());
            } else {
                // Clear guest information if no booking
                accommodationRow.setAccommodationGuests("");
                accommodationRow.setAccommodationBreakfast(false);
            }

            tableData.add(accommodationRow);
        }

        // Update the statistics displays
        txtNumBreakfasts.setText(Integer.toString(area.getNumBreakfasts()));
        txtNumRequireCleaning.setText(Integer.toString(area.getNumRequireCleaning()));
    }
    

    private void showAreaStatistics(Area area)
    {
        int numBreakfasts = area.getNumBreakfasts();
        int numRequireCleaning = area.getNumRequireCleaning();
        
        // Set the text fields to display the values
        txtNumBreakfasts.setText(Integer.toString(numBreakfasts));
        txtNumRequireCleaning.setText(Integer.toString(numRequireCleaning)); 
    }
    
    public void showAlert(AccommodationSystemException accommodationSystemException) 
    { 
      Platform.runLater(new Runnable() 
      {
        public void run() 
        {
          Alert alert = new Alert(Alert.AlertType.ERROR);
          alert.setTitle("Accommodation System");
          alert.setHeaderText("Accommodation Error");
          alert.setContentText(accommodationSystemException.getMessage());
          alert.showAndWait();
         }
       }
      );
    }

    @FXML
    private void checkInOnAction(ActionEvent event) {
        try {
            // Get input from text fields
            String firstName = txtFirstName.getText();
            String lastName = txtLastName.getText();
            String checkinDate = txtCheckInDate.getText();
            String numberGuests = txtNumberGuests.getText();

            // Get breakfast preference from checkbox
            boolean breakfastRequired = checkBreakfast.isSelected();

            // Validate inputs
            if (firstName.isEmpty() || lastName.isEmpty() || checkinDate.isEmpty() || numberGuests.isEmpty()) {
                showAlert(new AccommodationSystemException("All fields must be filled in"));
                return;
            }

            // Parse date
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yy");
            LocalDate checkinDateAsType = LocalDate.parse(checkinDate, formatter);

            // Create guest and booking
            Guest guest = new Guest(firstName, lastName);
            GuestBooking guestBooking = new GuestBooking(guest, 
                                                         checkinDateAsType,
                                                         Integer.valueOf(numberGuests));

            // Set breakfast requirement
            guestBooking.setBreakfastRequired(breakfastRequired);

            // Get accommodation information
            int selectedIndex = tblAccommodations.getSelectionModel().getSelectedIndex();
            if (selectedIndex < 0) {
                showAlert(new AccommodationSystemException("Please select an accommodation first"));
                return;
            }

            AccommodationRow accommodationRow = tblAccommodations.getSelectionModel().getSelectedItem();
            Accommodation accommodation = accommodationRow.getAccommodation();

            // Perform check-in
            accommodation.checkin(guestBooking);

            // Update UI
            Area area = cbArea.getValue();
            populateTable(area);
            showAreaStatistics(area);

            // Re-select the accommodation
            tblAccommodations.getSelectionModel().select(selectedIndex);

        } catch (DateTimeParseException e) {
            showAlert(new AccommodationSystemException("Invalid date format. Please use DD-MM-YY"));
        } catch (NumberFormatException e) {
            showAlert(new AccommodationSystemException("Invalid number of guests. Please enter a number"));
        } catch (AccommodationSystemException e) {
            showAlert(e);
        } catch (Exception e) {
            showAlert(new AccommodationSystemException("An unexpected error occurred: " + e.getMessage()));
        }
    }

    private void clearCheckinDetails() {
        txtFirstName.setText("");
        txtLastName.setText("");
        txtCheckInDate.setText("");
        txtNumberGuests.setText("");
        checkBreakfast.setSelected(false); // Reset breakfast checkbox
    }
    
    private void displayCheckinDetails(GuestBooking guestBooking) {
        txtFirstName.setText(guestBooking.getGuest().getFirstName());
        txtLastName.setText(guestBooking.getGuest().getLastName());

        String formattedDate = guestBooking.getCheckinDate().format(DateTimeFormatter.ofPattern("dd-MM-yy"));
        txtCheckInDate.setText(formattedDate);

        txtNumberGuests.setText(String.valueOf(guestBooking.getNumberOfGuests()));

        // Set checkbox state based on booking
        checkBreakfast.setSelected(guestBooking.isBreakfastRequired());
    }

    @FXML
    private void checkOutOnAction(ActionEvent event) {
        int selectedIndex = tblAccommodations.getSelectionModel().getSelectedIndex();
        if (selectedIndex >= 0) {
            AccommodationRow accommodationRow = tblAccommodations.getSelectionModel().getSelectedItem();
            Accommodation accommodation = accommodationRow.getAccommodation();

            if (!accommodation.hasGuestBooking()) {
                showAlert(new AccommodationSystemException("No guest is currently checked into this accommodation"));
                return;
            }

            // Implement checkout logic
            // This would involve creating a checkout method in the Accommodation class
            // For now, we'll simulate it by setting necessary properties
            accommodation.setAccommodationStatus(CleaningStatus.Status.DIRTY);

            // Clear guest booking - this would need a proper method in Accommodation class
            // accommodation.checkout(); 

            // Refresh the display
            Area area = cbArea.getValue();
            populateTable(area);
            showAreaStatistics(area);

            // Re-select the accommodation
            tblAccommodations.getSelectionModel().select(selectedIndex);

            // Clear check-in details form
            clearCheckinDetails();
        } else {
            showAlert(new AccommodationSystemException("Please select an accommodation first"));
        }
    }    
}
