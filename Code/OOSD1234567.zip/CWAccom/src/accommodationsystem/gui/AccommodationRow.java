package accommodationsystem.gui;

// REPRESENTS A SINGLE ROW IN THE TABLE
import accommodationsystem.model.Accommodation;
import javafx.beans.property.SimpleStringProperty;

public class AccommodationRow {
    private SimpleStringProperty accommodationNumber;
    private SimpleStringProperty accommodationType;
    private SimpleStringProperty accommodationOccupancy;
    private SimpleStringProperty accommodationAvailable;
    private SimpleStringProperty accommodationStatus;
    private SimpleStringProperty accommodationGuests;
    private SimpleStringProperty accommodationBreakfast;
    private Accommodation accommodation;
    
    AccommodationRow(int accommodationNumber,
                     String accommodationType,
                     String accommodationOccupancy,
                     String accommodationAvailable,
                     String accommodationStatus,
                     Accommodation accommodation)
    {
        this.accommodationNumber = new SimpleStringProperty(Integer.toString(accommodationNumber));
        this.accommodationType = new SimpleStringProperty(accommodationType);
        this.accommodationOccupancy = new SimpleStringProperty(accommodationOccupancy);
        this.accommodationAvailable = new SimpleStringProperty(accommodationAvailable);
        this.accommodationStatus = new SimpleStringProperty(accommodationStatus);
        this.accommodationGuests = new SimpleStringProperty("");
        this.accommodationBreakfast = new SimpleStringProperty("No");
        this.accommodation = accommodation;
    }

    public String getAccommodationNumber()
    {
        return accommodationNumber.get();
    }

    public String getAccommodationType()
    {
        return accommodationType.get();
    }
    
    public String getAccommodationOccupancy(){
        return accommodationOccupancy.get();
    }
    
    public String getAccommodationAvailable(){
        return accommodationAvailable.get();
    }
    
    public String getAccommodationGuests(){
        return accommodationGuests.get();
    }
    
    public String getAccommodationStatus(){
        return accommodationStatus.get();
    }
    
    // Getter for the TableView
    public String getAccommodationBreakfast(){
        return accommodationBreakfast.get();
    }
    
    public Accommodation getAccommodation()
    {
        return accommodation;
    }

    // Setter for breakfast status that accepts a boolean
    public void setAccommodationBreakfast(boolean hasBreakfast) {
        this.accommodationBreakfast.set(hasBreakfast ? "Yes" : "No");
    }
    
    // Setter for accommodation guests
    public void setAccommodationGuests(String guests) {
        this.accommodationGuests.set(guests);
    }
    

}

