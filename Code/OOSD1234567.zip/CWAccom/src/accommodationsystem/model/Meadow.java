
package accommodationsystem.model;

public class Meadow extends Area
{
    @Override
    public String getName()
    {
        return "Meadow";
    }

    @Override
    public String getDescription()
    {
        return "Idyllic and serene environment";
    }
 
}


