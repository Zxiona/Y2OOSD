package accommodationsystem.model;

import java.time.LocalDate;

public class GuestBooking {
    private Guest guest;
    private LocalDate checkinDate;
    private int numberOfGuests;
    private boolean breakfastRequired;

    public GuestBooking(Guest guest, LocalDate checkinDate, int numberOfGuests) {
        this.guest = guest;
        this.checkinDate = checkinDate;
        this.numberOfGuests = numberOfGuests;
        this.breakfastRequired = false; // Default to no breakfast
    }

    public Guest getGuest() {
        return guest;
    }

    public LocalDate getCheckinDate() {
        return checkinDate;
    }

    public int getNumberOfGuests() {
        return numberOfGuests;
    }

    public boolean isBreakfastRequired() {
        return breakfastRequired;
    }

    public void setBreakfastRequired(boolean breakfastRequired) {
        this.breakfastRequired = breakfastRequired;
    }
    
    public int getBreakfastsRequired() {
        return breakfastRequired ? numberOfGuests : 0;
    }
}