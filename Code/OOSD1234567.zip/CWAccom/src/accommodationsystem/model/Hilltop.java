
package accommodationsystem.model;

public class Hilltop extends Area
{
    @Override
    public String getName()
    {
        return "Hilltop";
    }

    @Override
    public String getDescription()
    {
        return "Stunning panoramic views";
    }
  
}



