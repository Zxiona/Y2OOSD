package accommodationsystem.model;

import java.util.ArrayList;

public abstract class Area
{
    private ArrayList<Accommodation> accommodations;
    
    public abstract String getName();
    public abstract String getDescription();
    
    Area()
    {
        accommodations = new ArrayList<Accommodation>();
    }
    
    public void addAccommodation(Accommodation accommodation)
    {
        accommodations.add(accommodation);
    }
    
    public ArrayList<Accommodation> getAccommodations()
    {
        return accommodations;
    }
    
    public int getNumBreakfasts() {
        int totalBreakfasts = 0;
        for (Accommodation accommodation : accommodations) {
            if (accommodation.hasGuestBooking()) {
                GuestBooking booking = accommodation.getGuestBooking();
                if (booking.isBreakfastRequired()) {
                    totalBreakfasts += booking.getNumberOfGuests();
                }
            }
        }
        return totalBreakfasts;
    }
    
    public int getNumRequireCleaning() {
        int totalRequireCleaning = 0;
        
        for (Accommodation accommodation : accommodations) {
            // Get the current cleaning status of the accommodation
            CleaningStatus.Status status = accommodation.getAccommodationStatus();
            
            // Check if the status is DIRTY or MAINTENANCE
            if (status == CleaningStatus.Status.DIRTY || 
                status == CleaningStatus.Status.MAINTENANCE) {
                totalRequireCleaning++;
            }
        }
        
        return totalRequireCleaning;
    }
    
    @Override
    public String toString() 
    {
        return getName();
    }
}
