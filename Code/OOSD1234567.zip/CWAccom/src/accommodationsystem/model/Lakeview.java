
package accommodationsystem.model;

public class Lakeview extends Area
{
    @Override
    public String getName()
    {
        return "Lakeview";
    }

    @Override
    public String getDescription()
    {
        return "Peaceful waterfront views";
    }

}


