package accommodationsystem.model;

import accommodationsystem.model.CleaningStatus;
import accommodationsystem.model.CleaningStatus.Status;

public class Accommodation
{
    private int accommodationNumber;
    private String accommodationType;
    private String accommodationOccupancy;
    private String accommodationAvailable;
    private Status accommodationStatus;
    private int accommodates;
    private GuestBooking guestBooking;
    private int price;
    
    // Constructor
    public Accommodation(int accommodationNumber, String accommodationType, int accommodates, int price)
    {
        this.accommodationNumber = accommodationNumber;
        this.accommodationType = accommodationType;
        this.accommodates = accommodates;
        this.price = price;
        this.accommodationStatus = Status.CLEAN;
    }
    
    public int getAccommodationNumber()
    {
        return accommodationNumber;
    }
    
    public String getAccommodationType()
    {
        return accommodationType;
    }

    public int getAccommodates()
    {
        return accommodates;
    }
    
    public String getAccommodationOccupancy()
    {
        accommodationOccupancy = "Unoccupied";
        if (hasGuestBooking()) {
            accommodationOccupancy = "Occupied";
        }
        
        return accommodationOccupancy;
    }
    
    public String getAccommodationAvailable()
    {
        accommodationAvailable = "Available";
        if (hasGuestBooking()) {
            accommodationAvailable = "Unavailable";
        }
        
        return accommodationAvailable;
    }
    
    public Status getAccommodationStatus() {
        
        return accommodationStatus;
    }
    
    public String getCleaningStatus()
    {
        Status status = getAccommodationStatus();
        String strStatus = "";
        
        strStatus = switch (status) {
            case CLEAN -> "Clean";
            case DIRTY -> "Dirty";
            default -> "Maintenance";
        };
        
        return strStatus;
    }
        
    public void checkin(GuestBooking guestBooking)
            throws AccommodationSystemException
    {        
        // Ensure the number of guests does not exceed the number of guests the accommodation can sleep
        if (guestBooking.getNumberOfGuests() > this.getAccommodates())
        {
            throw new AccommodationSystemException("The number of guests exceeds the number of guests the accommodation can sleep");
        }
        
        // We can add a guest booking, the room has been cleaned and ready for guests
        this.guestBooking = guestBooking;
    }
    
    public boolean hasGuestBooking()
    {
        // If the guest booking is not NULL we have an associated booking.
        return (this.guestBooking != null);      
    }

    public GuestBooking getGuestBooking()
    {
        return guestBooking;
    }

    public int getPrice() {
        return this.price;
    }
    
    // Add this method to the Accommodation class if it doesn't exist
    public void setAccommodationStatus(CleaningStatus.Status status) {
        this.accommodationStatus = status;
    }
}
