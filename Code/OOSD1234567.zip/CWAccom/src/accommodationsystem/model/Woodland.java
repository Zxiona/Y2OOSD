
package accommodationsystem.model;

public class Woodland extends Area
{

    @Override
    public String getName()
    {
        return "Woodland";
    }

    @Override
    public String getDescription()
    {
        return "Tranquil woodland area";
    }

}

